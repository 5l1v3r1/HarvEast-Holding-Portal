-- phpMyAdmin SQL Dump
-- version 4.4.15.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Час створення: Лип 07 2017 р., 14:23
-- Версія сервера: 5.5.45-MariaDB
-- Версія PHP: 5.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `harveast_portal`
--

-- --------------------------------------------------------

--
-- Структура таблиці `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `media` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_anchored` tinyint(1) NOT NULL DEFAULT '0',
  `is_highlighted` tinyint(1) NOT NULL DEFAULT '0',
  `city_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` int(10) unsigned NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anchored_from` timestamp NULL DEFAULT NULL,
  `anchored_to` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `articles`
--

INSERT INTO `articles` (`id`, `name`, `body`, `media`, `is_anchored`, `is_highlighted`, `city_id`, `department_id`, `views`, `user_id`, `slug`, `anchored_from`, `anchored_to`, `created_at`, `updated_at`) VALUES
(66, 'Відбувся «Перший східноукраїнський День поля» на базі підприємств кампанії «HarvEast Holding»', '14 червня 2017 року на базі підприємств кампанії &laquo;HarvEast Holding&raquo; відбувся &laquo;Перший східноукраїнський День поля&raquo;. В рамках цього заходу представник кампанії AMAKO здійснив показ сільськогосподарської техніки відомих брендів &laquo;Мессей Фергюссон&raquo;, &laquo;Івеко&raquo;, &laquo;Кьокерлін&raquo; та ін. Було проведено демонстрацію зазначеної техніки у роботі.<br /><br />Також увазі учасників Дня поля було представлено спеціальний об&rsquo;єкт, на території якого здійснюється приготування робочих сумішей для хімічного обробітку посівів сільськогосподарських культур. Тут представниками кампанії &laquo;Field&raquo; керівникам агрономічних служб та іншим зацікавленим особам було дано рекомендації щодо дотримання оптимальних норм витрат хімічних препаратів для приготування таких сумішей.<br /><br />Крім того, для учасників заходу представниками кампанії &laquo;HarvEast Holding&raquo; було проведено показ посівів озимої пшениці, ярого ячменю та льону різних строків посіву, гороху. Особливу увагу керівників та агрономів агроформувань привернули посіви чечевиці. Протягом останнього часу цій культурі в &laquo;HarvEast Holding&raquo; приділяють важливе значення здебільшого через її високу рентабельність.<br /><br />Слід зазначити, що День поля був проведений на високому рівні та, без сумніву, був корисний для всіх присутніх.', '<img src="/storage/app/public/articles/vіdbuvsya-pershiy-shіdnoukraїnskiy-den-polya-na-bazі-pіdpriєmstv-kampanії-harveast-holding-2017-06-16/background.jpg">', 0, 1, 0, 0, 4, 1, 'vіdbuvsya-pershiy-shіdnoukraїnskiy-den-polya-na-bazі-pіdpriєmstv-kampanії-harveast-holding-2017-07-06', '2017-06-14 11:06:00', '2017-12-31 13:06:00', '2017-06-16 08:06:37', '2017-07-06 14:21:35'),
(72, 'В Харвист стартовал очередной конкурс мини-грантов «Мое село — сделаем лучшим вместе»', 'Принять участие в конкурсе смогут проекты громад из восьмидесяти сел четырех районов Донецкой области. Заявки принимаются с 20 мая по 20 июня 2017 года. Победители из каждого района получат мини-гранты на реализацию своих проектов по благоустройству села.<br /><br />К участию в конкурсе допускаются активные жители, общественные организации, которые должны предоставить на рассмотрение жюри проекты, напр<span class="text_exposed_show">авленные на решение локальных проблем территориальных громад по следующим направлениям: жилищно-коммунальное хозяйство, пропаганда здорового образа жизни, образование, культура и творчество, социальная защита, благоустройство села. Важно, чтобы в проекте принимали участие громады, органы власти и бизнес. Доля участия каждой из сторон должна быть прописана в конкурсной заявке. Итоги конкурса будут подведены в середине июля.</span><br /><br /><span class="text_exposed_show">&laquo;В прошлом году конкурс мини-грантов был успешно проведен и получил ряд положительных отзывов. Тринадцать проектов успешно запустили в 4-х районах Донецкой области. Все проекты были направлены на улучшение качества жизни сельчан. В этом году мы приняли решение продолжить проведение конкурса мини-грантов. Мы хотим поддержать стремление активных сельчан сделать жизнь у себя лучше, облагородить территорию, проявить заботу о ближних. Важное условие конкурса &mdash; реализация проекта должна осуществиться совместными усилиями бизнеса, власти и общества. Совместная реализация проекта позволит бережнее относиться к его результату, докажет, что только вместе можно добиться по-настоящему хороших результатов и сделать жизнь вокруг себя лучше&raquo;, &mdash; отметила Елена Зубарева, PR-менеджер Харвист.</span>', '<img src="/storage/app/public/articles/v-harvist-startoval-ocherednoy-konkurs-mini-grantov-moe-selo-—-sdelaem-luchshim-vmeste-2017-06-16/18740114_1442115665847672_7608073934472608815_n.jpg">', 0, 0, 0, 0, 1, 1, 'v-harvist-startoval-ocherednoy-konkurs-mini-grantov-moe-selo-—-sdelaem-luchshim-vmeste-2017-07-03', '2017-06-16 01:49:00', '2017-12-31 03:49:00', '2017-06-16 10:51:08', '2017-07-03 14:09:53'),
(73, 'День поля. Фото и видео отчеты', '<a href="M:\\_Общедоступная папка_\\Field day">M:\\_Общедоступная папка_\\Field day</a><br /><br /><a href="M:\\Корпоративные фотографии\\2017\\День поля_2017">M:\\Корпоративные фотографии\\2017\\День поля_2017</a>', '<img src="/storage/app/public/articles/den-polya-foto-i-video-otchetyi-2017-07-06/IMG_1568.jpg">', 1, 0, 0, 0, 1, 1, 'den-polya-foto-i-video-otchetyi-2017-07-06', '2017-07-02 20:06:00', '2017-12-30 23:06:00', '2017-07-03 14:06:21', '2017-07-06 14:25:06');

-- --------------------------------------------------------

--
-- Структура таблиці `article_tags`
--

CREATE TABLE IF NOT EXISTS `article_tags` (
  `article_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `article_tags`
--

INSERT INTO `article_tags` (`article_id`, `tag_id`) VALUES
(53, 24),
(54, 26),
(55, 38),
(55, 39),
(59, 40),
(59, 41),
(60, 42),
(60, 43),
(62, 44),
(62, 45),
(65, 46),
(65, 47),
(66, 49),
(66, 50);

-- --------------------------------------------------------

--
-- Структура таблиці `article_views`
--

CREATE TABLE IF NOT EXISTS `article_views` (
  `article_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `article_views`
--

INSERT INTO `article_views` (`article_id`, `user_id`) VALUES
(66, 1),
(66, 403),
(66, 405),
(66, 417),
(72, 1),
(73, 1);

-- --------------------------------------------------------

--
-- Структура таблиці `bids`
--

CREATE TABLE IF NOT EXISTS `bids` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `fields` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL,
  `responsible_id` tinyint(3) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `bids`
--

INSERT INTO `bids` (`id`, `name`, `category_id`, `fields`, `published`, `responsible_id`, `created_at`, `updated_at`) VALUES
(38, 'тестовый вопрос', 7, '[{ "field":"text", "label":"тест1", "required":0},{ "field":"number", "label":"тест2", "min":1, "max":33, "step":1, "required":0},{ "field":"texts", "label":"тест5", "texts":[{ "text":"текст1"},{ "text":"текст2"}], "box_type":"radio", "required": 0},{ "field":"upload", "label":"тест3", "required":0},{ "field":"files", "label":"тест4", "files":[{ "src":"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg"},{ "src":"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg"}], "box_type":"radio", "required": 0}]', 1, 6, '2017-06-16 09:01:56', '2017-06-16 09:54:01');

-- --------------------------------------------------------

--
-- Структура таблиці `bid_categories`
--

CREATE TABLE IF NOT EXISTS `bid_categories` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `bid_categories`
--

INSERT INTO `bid_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(7, 'тестовая категория', '2017-06-16 08:59:38', '2017-06-16 08:59:38');

-- --------------------------------------------------------

--
-- Структура таблиці `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '1',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблиці `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(3, 'Киев', '2017-06-13 09:51:27', '2017-06-13 09:51:27');

-- --------------------------------------------------------

--
-- Структура таблиці `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(10) unsigned NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `article_id` int(10) unsigned NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблиці `data_rows`
--

CREATE TABLE IF NOT EXISTS `data_rows` (
  `id` int(10) unsigned NOT NULL,
  `data_type_id` int(10) unsigned NOT NULL,
  `field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `browse` tinyint(1) NOT NULL DEFAULT '1',
  `read` tinyint(1) NOT NULL DEFAULT '1',
  `edit` tinyint(1) NOT NULL DEFAULT '1',
  `add` tinyint(1) NOT NULL DEFAULT '1',
  `delete` tinyint(1) NOT NULL DEFAULT '1',
  `details` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `data_rows`
--

INSERT INTO `data_rows` (`id`, `data_type_id`, `field`, `type`, `display_name`, `required`, `browse`, `read`, `edit`, `add`, `delete`, `details`) VALUES
(1, 1, 'id', 'number', 'id', 1, 0, 0, 0, 0, 0, NULL),
(2, 1, 'name', 'text', 'Имя', 1, 1, 1, 1, 1, 1, NULL),
(3, 1, 'email', 'text', 'email', 1, 1, 1, 1, 1, 1, NULL),
(4, 1, 'password', 'password', 'password', 1, 0, 0, 0, 0, 0, NULL),
(5, 1, 'remember_token', 'text', 'remember_token', 0, 0, 0, 0, 0, 0, NULL),
(6, 1, 'created_at', 'timestamp', 'created_at', 0, 1, 1, 0, 0, 0, NULL),
(7, 1, 'updated_at', 'timestamp', 'updated_at', 0, 0, 0, 0, 0, 0, NULL),
(9, 2, 'id', 'number', 'id', 1, 0, 0, 0, 0, 0, ''),
(10, 2, 'name', 'text', 'name', 1, 1, 1, 1, 1, 1, ''),
(11, 2, 'created_at', 'timestamp', 'created_at', 0, 0, 0, 0, 0, 0, ''),
(12, 2, 'updated_at', 'timestamp', 'updated_at', 0, 0, 0, 0, 0, 0, ''),
(13, 3, 'id', 'number', 'id', 1, 0, 0, 0, 0, 0, NULL),
(14, 3, 'name', 'text', 'Name', 1, 0, 0, 0, 0, 0, NULL),
(15, 3, 'created_at', 'timestamp', 'created_at', 0, 0, 0, 0, 0, 0, NULL),
(16, 3, 'updated_at', 'timestamp', 'updated_at', 0, 0, 0, 0, 0, 0, NULL),
(17, 3, 'display_name', 'text', 'Отображаемое название', 0, 1, 1, 1, 1, 1, NULL),
(18, 1, 'role_id', 'select_dropdown', 'Роль', 0, 1, 1, 1, 1, 1, '{"relationship":{"key":"id","label":"name"}}'),
(19, 5, 'id', 'number', 'id', 1, 0, 0, 0, 0, 0, NULL),
(20, 5, 'name', 'text', 'name', 1, 1, 0, 1, 1, 0, NULL),
(21, 5, 'created_at', 'timestamp', 'created_at', 0, 0, 0, 0, 0, 0, NULL),
(22, 5, 'updated_at', 'timestamp', 'updated_at', 0, 0, 0, 0, 0, 0, NULL),
(23, 10, 'id', 'number', 'id', 1, 0, 0, 0, 0, 0, NULL),
(24, 10, 'name', 'text', 'name', 1, 1, 0, 1, 1, 0, NULL),
(25, 10, 'created_at', 'timestamp', 'created_at', 0, 0, 0, 0, 0, 0, NULL),
(26, 10, 'updated_at', 'timestamp', 'updated_at', 0, 0, 0, 0, 0, 0, NULL),
(27, 6, 'id', 'number', 'id', 1, 0, 0, 0, 0, 0, NULL),
(28, 6, 'name', 'text', 'Название', 1, 1, 0, 1, 1, 0, NULL),
(29, 6, 'created_at', 'timestamp', 'created_at', 0, 0, 0, 0, 0, 0, NULL),
(30, 6, 'updated_at', 'timestamp', 'updated_at', 0, 0, 0, 0, 0, 0, NULL),
(31, 11, 'id', 'number', 'id', 1, 0, 0, 0, 0, 0, ''),
(32, 11, 'name', 'text', 'name', 1, 1, 1, 1, 1, 1, ''),
(33, 11, 'created_at', 'timestamp', 'created_at', 0, 0, 0, 0, 0, 0, ''),
(34, 11, 'updated_at', 'timestamp', 'updated_at', 0, 0, 0, 0, 0, 0, ''),
(35, 12, 'id', 'checkbox', 'Id', 1, 0, 0, 0, 0, 0, NULL),
(36, 12, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL),
(37, 12, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL),
(38, 12, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL),
(39, 1, 'birthday', 'timestamp', 'День рождения', 1, 1, 1, 1, 1, 1, NULL),
(40, 1, 'city_id', 'select_dropdown', 'Город', 1, 1, 1, 1, 1, 1, NULL),
(41, 1, 'department_id', 'select_dropdown', 'Департамент', 1, 1, 1, 1, 1, 1, NULL),
(42, 1, 'position_id', 'select_dropdown', 'Должность', 1, 1, 1, 1, 1, 1, NULL),
(43, 1, 'boss_id', 'select_dropdown', 'Начальник', 1, 1, 1, 1, 1, 1, NULL),
(44, 1, 'photo', 'checkbox', 'Фото', 1, 1, 1, 1, 1, 1, NULL),
(45, 4, 'id', 'checkbox', 'Id', 1, 0, 0, 0, 0, 0, NULL),
(46, 4, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL),
(47, 4, 'body', 'text_area', 'Body', 1, 1, 1, 1, 1, 1, NULL),
(48, 4, 'media', 'image', 'Media', 0, 0, 0, 1, 1, 1, NULL),
(49, 4, 'is_anchored', 'checkbox', 'Is Anchored', 1, 1, 1, 1, 1, 1, NULL),
(50, 4, 'is_highlighted', 'checkbox', 'Is Highlighted', 1, 1, 1, 1, 1, 1, NULL),
(51, 4, 'city_id', 'select_dropdown', 'City Id', 0, 1, 1, 1, 1, 1, NULL),
(52, 4, 'department_id', 'select_dropdown', 'Department Id', 0, 1, 1, 1, 1, 1, NULL),
(53, 4, 'views', 'checkbox', 'Views', 1, 0, 0, 0, 0, 0, NULL),
(54, 4, 'user_id', 'checkbox', 'User Id', 1, 0, 0, 0, 0, 0, NULL),
(55, 4, 'slug', 'text', 'Slug', 1, 1, 1, 1, 1, 1, NULL),
(56, 4, 'anchored_from', 'timestamp', 'Anchored From', 0, 1, 1, 1, 1, 1, NULL),
(57, 4, 'anchored_to', 'timestamp', 'Anchored To', 0, 1, 1, 1, 1, 1, NULL),
(58, 4, 'created_at', 'timestamp', 'Created At', 0, 1, 1, 1, 0, 1, NULL),
(59, 4, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL),
(60, 14, 'id', 'checkbox', 'Id', 1, 0, 0, 0, 0, 0, NULL),
(61, 14, 'name', 'text', 'Name', 1, 1, 1, 1, 1, 1, NULL),
(62, 14, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL),
(63, 14, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL),
(64, 9, 'id', 'checkbox', 'Id', 1, 0, 0, 0, 0, 0, NULL),
(65, 9, 'name', 'text', 'Название', 1, 1, 1, 1, 1, 1, '{"validation":{"rule":"required|max:12"}}'),
(66, 9, 'category_id', 'select_dropdown', 'Категория', 1, 1, 1, 1, 1, 1, '{"relationship":{"key":"id","label":"name"}}'),
(67, 9, 'link', 'file', 'Документ', 1, 1, 1, 1, 1, 1, NULL),
(68, 9, 'description', 'text_area', 'Описание', 0, 1, 1, 1, 1, 1, NULL),
(69, 9, 'created_at', 'timestamp', 'Created At', 0, 0, 0, 0, 0, 0, NULL),
(70, 9, 'updated_at', 'timestamp', 'Updated At', 0, 0, 0, 0, 0, 0, NULL),
(71, 9, 'photo', 'image', 'Превью документа', 0, 1, 1, 1, 1, 1, NULL),
(72, 3, 'bid_responsible', 'checkbox', 'Ответственен за заявки', 1, 0, 0, 0, 0, 0, NULL),
(73, 1, 'is_active', 'checkbox', 'Is Active', 1, 0, 0, 0, 0, 0, NULL),
(74, 1, 'userscol', 'checkbox', 'Userscol', 0, 1, 1, 1, 1, 1, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `data_types`
--

CREATE TABLE IF NOT EXISTS `data_types` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_singular` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name_plural` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `controller` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generate_permissions` tinyint(1) NOT NULL DEFAULT '0',
  `server_side` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `data_types`
--

INSERT INTO `data_types` (`id`, `name`, `slug`, `display_name_singular`, `display_name_plural`, `icon`, `model_name`, `controller`, `description`, `generate_permissions`, `server_side`, `created_at`, `updated_at`) VALUES
(1, 'users', 'users', 'Пользователь', 'Пользователи', 'voyager-person', 'App\\User', NULL, NULL, 1, 0, '2017-04-20 06:42:59', '2017-05-16 15:27:25'),
(2, 'menus', 'menus', 'Menu', 'Menus', 'voyager-list', 'TCG\\Voyager\\Models\\Menu', '', '', 1, 0, '2017-04-20 06:42:59', '2017-04-20 06:42:59'),
(3, 'roles', 'roles', 'Роль', 'Роли', 'voyager-lock', 'TCG\\Voyager\\Models\\Role', NULL, NULL, 1, 0, '2017-04-20 06:42:59', '2017-05-09 12:30:38'),
(4, 'articles', 'articles', 'Статьи', 'Статьи', 'voyager-helm', 'App\\Article', NULL, NULL, 1, 0, '2017-04-20 06:42:59', '2017-05-11 09:09:39'),
(5, 'cities', 'cities', 'City', 'Cities', NULL, 'App\\City', NULL, NULL, 1, 0, '2017-04-20 06:42:59', '2017-05-22 08:33:17'),
(6, 'departments', 'departments', 'Department', 'Departments', NULL, 'App\\Department', NULL, NULL, 1, 0, '2017-04-20 06:42:59', '2017-05-09 09:00:19'),
(7, 'infos', 'infos', 'Info', 'Infos', '', 'App\\Info', '', '', 1, 0, '2017-04-20 06:43:00', '2017-04-20 06:43:00'),
(8, 'document-categories', 'document_categories', 'Document Category', 'Document Categories', '', 'App\\DocumentCategory', '', '', 1, 0, '2017-04-20 06:43:00', '2017-04-20 06:43:00'),
(9, 'documents', 'documents', 'Документ', 'Документы', NULL, 'App\\Document', NULL, NULL, 1, 0, '2017-04-20 06:43:00', '2017-05-09 09:01:15'),
(10, 'positions', 'positions', 'Position', 'Positions', NULL, 'App\\Position', NULL, NULL, 1, 0, '2017-04-20 06:43:00', '2017-05-22 08:34:38'),
(11, 'polls', 'polls', 'Опрос', 'Опросы', '', 'App\\Poll', '', '', 1, 0, '2017-04-20 06:43:00', '2017-04-20 06:43:00'),
(12, 'bid_categories', 'bid_categories', 'Bid Category', 'Bid Categories', NULL, 'App\\BidCategory', NULL, NULL, 1, 0, '2017-04-20 08:29:47', '2017-04-20 08:31:49'),
(13, 'head_of_departments', 'heads', 'Глава департамента', 'Главы департаментов', NULL, '', NULL, NULL, 1, 0, NULL, NULL),
(14, 'document_categories', 'document-categories', 'Document Category', 'Document Categories', NULL, 'App\\DocumentCategory', NULL, NULL, 1, 0, '2017-05-02 08:08:53', '2017-05-02 08:08:53'),
(15, 'hr_managers', 'hr_managers', 'HR мэнеджер', 'HR мэнеджеры', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(16, 'bids', 'bids', 'Заявка', 'Заявки', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(19, 'dismissed', 'dismissed', 'Уволенный Сотрудник', 'Уволенные сотрудники', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL),
(20, 'backgrounds', 'b_image', 'Фон', 'Фоны', NULL, NULL, NULL, NULL, 1, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `departments`
--

CREATE TABLE IF NOT EXISTS `departments` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `departments`
--

INSERT INTO `departments` (`id`, `name`, `created_at`, `updated_at`) VALUES
(16, 'Отдел производственного анализа и планирования', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(17, 'Финансовый департамент', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(18, 'Департамент IT', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(19, 'Производственный департамент', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(20, 'Коммерческий департамент', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(21, 'Департамент по связям с общественностью', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(22, 'Департамент по персоналу', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(23, 'Отдел бухгалтерского и налогового учета', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(24, 'Юридический департамент', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(25, '-', '2017-06-16 11:28:24', '2017-06-16 11:28:24');

-- --------------------------------------------------------

--
-- Структура таблиці `documents`
--

CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `documents`
--

INSERT INTO `documents` (`id`, `name`, `category_id`, `link`, `photo`, `description`, `created_at`, `updated_at`) VALUES
(6, 'важный лев', 1, 'documents/June2017/r9N74F2cGpk7xPsycbYC.jpg', 'documents/June2017/Y15Y1Hom1L0IC0hl56AW.jpg', 'картинка важного льва', '2017-06-13 09:10:41', '2017-06-13 09:10:41');

-- --------------------------------------------------------

--
-- Структура таблиці `document_categories`
--

CREATE TABLE IF NOT EXISTS `document_categories` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `document_categories`
--

INSERT INTO `document_categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'НПА', NULL, NULL),
(2, 'Приказы', NULL, NULL),
(3, 'Остальные документы', '2017-05-03 14:36:58', '2017-05-03 14:36:58');

-- --------------------------------------------------------

--
-- Структура таблиці `infos`
--

CREATE TABLE IF NOT EXISTS `infos` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `photo` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` int(10) unsigned DEFAULT NULL,
  `department_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `infos`
--

INSERT INTO `infos` (`id`, `name`, `body`, `photo`, `city_id`, `department_id`, `created_at`, `updated_at`) VALUES
(33, NULL, NULL, NULL, 3, 16, '2017-07-03 13:01:27', '2017-07-03 13:01:27'),
(34, 'КОНКУРС ФОТО на приз Генерального директора', 'Победитель - Казмин Артем', '/storage/app/public/infos/Kazmin Artem_6.jpg', 3, 17, '2017-07-03 13:01:27', '2017-07-04 08:07:40'),
(35, 'КОНКУРС ФОТО на приз Генерального директора', 'Победитель - Казмин Артем', '/storage/app/public/infos/Kazmin Artem_6.jpg', 3, 18, '2017-07-03 13:01:27', '2017-07-04 08:07:40'),
(36, NULL, NULL, NULL, 3, 19, '2017-07-03 13:01:27', '2017-07-03 13:01:27'),
(37, NULL, NULL, NULL, 3, 20, '2017-07-03 13:01:27', '2017-07-03 13:01:27'),
(38, NULL, NULL, NULL, 3, 21, '2017-07-03 13:01:27', '2017-07-04 08:03:05'),
(39, NULL, NULL, NULL, 3, 22, '2017-07-03 13:01:27', '2017-07-03 13:01:27'),
(40, NULL, NULL, NULL, 3, 23, '2017-07-03 13:01:27', '2017-07-03 13:01:27'),
(41, NULL, NULL, NULL, 3, 24, '2017-07-03 13:01:27', '2017-07-03 13:01:27'),
(42, NULL, NULL, NULL, 3, 25, '2017-07-03 13:01:27', '2017-07-03 13:01:27');

-- --------------------------------------------------------

--
-- Структура таблиці `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `menus`
--

INSERT INTO `menus` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2017-04-20 06:43:03', '2017-04-20 06:43:03');

-- --------------------------------------------------------

--
-- Структура таблиці `menu_items`
--

CREATE TABLE IF NOT EXISTS `menu_items` (
  `id` int(10) unsigned NOT NULL,
  `menu_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `icon_class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parameters` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп даних таблиці `menu_items`
--

INSERT INTO `menu_items` (`id`, `menu_id`, `title`, `url`, `target`, `icon_class`, `color`, `parent_id`, `order`, `created_at`, `updated_at`, `route`, `parameters`) VALUES
(1, 1, 'Вернутся на портал', '/', '_self', 'voyager-home', '#000000', NULL, 9, '2017-04-19 05:37:12', '2017-05-03 12:18:57', NULL, ''),
(3, 1, 'Сотрудники', '/admin/users', '_self', 'voyager-person', '#000000', 21, 1, '2017-04-19 05:37:12', '2017-05-15 12:15:27', NULL, ''),
(4, 1, 'Роли сотрудников', '/admin/roles', '_self', 'voyager-bookmark', '#000000', 21, 2, '2017-04-19 05:37:12', '2017-05-15 12:16:20', NULL, ''),
(6, 1, 'Menu Builder', '/admin/menus', '_self', 'voyager-list', NULL, 5, 1, '2017-04-19 05:37:12', '2017-04-20 04:37:11', NULL, NULL),
(7, 1, 'Database', '/admin/database', '_self', 'voyager-data', NULL, 5, 2, '2017-04-19 05:37:12', '2017-04-20 04:37:11', NULL, NULL),
(9, 1, 'Города', '/admin/cities', '_self', 'voyager-world', '#000000', 11, 1, '2017-04-19 05:37:12', '2017-04-20 05:07:17', NULL, ''),
(10, 1, 'Департаменты', '/admin/departments', '_self', 'voyager-pie-chart', '#000000', 11, 2, '2017-04-19 05:37:12', '2017-04-20 05:05:51', NULL, ''),
(11, 1, 'Структура компании', '/admin/departments', '_self', 'voyager-company', '#000000', NULL, 6, '2017-04-19 05:37:12', '2017-05-03 12:18:57', NULL, ''),
(12, 1, 'Должности', '/admin/positions', '_self', 'voyager-group', '#000000', 11, 3, '2017-04-19 05:37:12', '2017-04-20 05:05:36', NULL, ''),
(13, 1, 'Главы департаментов', '/admin/heads', '_self', 'voyager-trophy', '#000000', 21, 3, '2017-04-19 05:37:12', '2017-04-20 04:57:18', NULL, ''),
(14, 1, 'Свободный блок', '/admin/infos', '_self', 'voyager-photos', '#000000', NULL, 8, '2017-04-19 05:37:12', '2017-05-03 12:18:57', NULL, ''),
(15, 1, 'Документы', '/admin/documents', '_self', 'voyager-folder', '#000000', NULL, 7, '2017-04-19 05:37:12', '2017-05-03 12:18:57', NULL, ''),
(16, 1, 'Категории документов', '/admin/document-categories', '_self', 'voyager-categories', '#000000', 15, 2, '2017-04-19 05:37:12', '2017-04-20 05:04:46', NULL, ''),
(17, 1, 'Документы', '/admin/documents', '_self', 'voyager-file-text', '#000000', 15, 1, '2017-04-19 05:37:12', '2017-04-20 05:04:33', NULL, ''),
(18, 1, 'Новости', '/admin/articles', '_self', 'voyager-news', '#000000', NULL, 2, '2017-04-19 05:37:12', '2017-05-16 09:10:30', NULL, ''),
(19, 1, 'Опросы', '/admin/polls', '_self', 'voyager-list', '#000000', NULL, 3, '2017-04-19 05:37:12', '2017-04-20 05:02:03', NULL, ''),
(20, 1, 'Главная страница', '/admin', '_self', 'voyager-anchor', '#000000', NULL, 1, '2017-04-20 04:37:04', '2017-04-20 04:56:43', NULL, ''),
(21, 1, 'Структура сотрудников', '/admin/users', '_self', 'voyager-people', '#000000', NULL, 5, '2017-04-20 04:46:28', '2017-05-15 12:16:02', NULL, ''),
(22, 1, 'Заявки', '/admin/bids', '_self', 'voyager-mail', '#000000', 24, 1, '2017-04-20 08:26:08', '2017-04-20 09:45:50', NULL, ''),
(23, 1, 'Категории заявок', '/admin/bid_categories', '_self', 'voyager-credit-cards', '#000000', 24, 2, '2017-04-20 08:31:10', '2017-04-20 09:46:15', NULL, ''),
(24, 1, 'Заявки', '/admin/bids', '_self', 'voyager-receipt', '#000000', NULL, 4, '2017-04-20 09:44:14', '2017-05-09 11:05:39', NULL, ''),
(26, 1, 'HR - Менеджеры', '/admin/hr_managers', '_self', 'voyager-group', '#000000', 21, 4, '2017-05-03 12:18:29', '2017-05-09 12:22:22', NULL, ''),
(27, 1, 'Уволенные сотрудники', '/admin/dismissed', '_self', 'voyager-skull', '#000000', 21, 5, '2017-05-17 11:35:32', '2017-05-22 08:31:23', NULL, ''),
(28, 1, 'Изменить фон', '/admin/b_image', 'self', 'voyager-skull', '#000000', NULL, 20, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(37, '2014_10_12_000000_create_users_table', 1),
(38, '2014_10_12_100000_create_password_resets_table', 1),
(39, '2016_01_01_000000_add_voyager_user_fields', 1),
(40, '2016_01_01_000000_create_data_types_table', 1),
(41, '2016_01_01_000000_create_pages_table', 1),
(42, '2016_01_01_000000_create_posts_table', 1),
(43, '2016_02_15_204651_create_categories_table', 1),
(44, '2016_05_19_173453_create_menu_table', 1),
(45, '2016_10_21_190000_create_roles_table', 1),
(46, '2016_10_21_190000_create_settings_table', 1),
(47, '2016_11_30_135954_create_permission_table', 1),
(48, '2016_11_30_141208_create_permission_role_table', 1),
(49, '2016_12_26_201236_data_types__add__server_side', 1),
(50, '2017_01_13_000000_add_route_to_menu_items_table', 1),
(51, '2017_01_14_005015_create_translations_table', 1),
(52, '2017_01_15_000000_add_permission_group_id_to_permissions_table', 1),
(53, '2017_01_15_000000_create_permission_groups_table', 1),
(54, '2017_01_15_000000_make_table_name_nullable_in_permissions_table', 1),
(55, '2017_03_06_000000_add_controller_to_data_types_table', 1),
(56, '2017_03_09_085334_create_articles_table', 1),
(57, '2017_03_10_085316_create_polls_table', 1),
(58, '2017_03_10_093211_create_votes_table', 1),
(59, '2017_03_12_185520_create_options_table', 1),
(60, '2017_03_13_074331_create_cities_table', 1),
(61, '2017_03_13_074439_create_departments_table', 1),
(62, '2017_03_13_080525_create_tags_table', 1),
(63, '2017_03_13_080742_create_article_users_table', 1),
(64, '2017_03_13_121857_create_views_table', 1),
(65, '2017_03_15_103158_create_positions_table', 1),
(66, '2017_03_16_105307_create_documents_table', 1),
(67, '2017_03_16_105340_create_document_categories_table', 1),
(68, '2017_03_17_093434_create_bids_table', 1),
(69, '2017_03_17_093442_create_bid_categories_table', 1),
(70, '2017_03_17_125723_create_comments_table', 1),
(71, '2017_03_22_101059_create_infos_table', 1),
(72, '2017_04_14_125839_create_user_bids_table', 1),
(74, '2017_04_26_071628_create_role_departments_emails_table', 2);

-- --------------------------------------------------------

--
-- Структура таблиці `options`
--

CREATE TABLE IF NOT EXISTS `options` (
  `id` int(10) unsigned NOT NULL,
  `poll_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `votes` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `options`
--

INSERT INTO `options` (`id`, `poll_id`, `name`, `votes`, `created_at`, `updated_at`) VALUES
(75, 14, 'командный игрок', 0, '2017-07-03 13:18:25', '2017-07-03 13:18:25'),
(76, 14, 'лидер', 0, '2017-07-03 13:18:25', '2017-07-03 13:18:25'),
(77, 14, 'зависит от обстоятельств', 0, '2017-07-03 13:18:25', '2017-07-03 13:18:25'),
(78, 14, 'сам себе режиссер', 0, '2017-07-03 13:18:25', '2017-07-03 13:18:25');

-- --------------------------------------------------------

--
-- Структура таблиці `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('it@harveast.com', '$2y$10$/I/NaGKJcTunW0/P0qj8c.4wVAt6stP52ZyaE1WoNUOuECDlnLUiG', '2017-06-13 11:53:12'),
('Artem.Kazmin@harveast.com', '$2y$10$x/XKTVcc1pdYUnhe7V4mCecJ86YKsuskWgXjczsqCE/hyClK.oLvK', '2017-06-13 13:46:47'),
('Dmitry.Skornyakov@harveast.com', '$2y$10$V72/pGoAl2rAFKMQDooe4ubKiQFFl.IllFMtDaxgruJ/Scz8yE./K', '2017-06-26 11:20:02'),
('development4@leostudio.com.ua', '$2y$10$77X5ExB6tORt0hHEoQAsZOSMdi.m8AJ2k1dS4g4.c.qremMz2d2m.', '2017-07-03 09:39:12');

-- --------------------------------------------------------

--
-- Структура таблиці `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(10) unsigned NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `permission_group_id` int(10) unsigned DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `permissions`
--

INSERT INTO `permissions` (`id`, `key`, `table_name`, `created_at`, `updated_at`, `permission_group_id`) VALUES
(1, 'browse_admin', NULL, '2017-04-20 06:43:05', '2017-04-20 06:43:05', NULL),
(2, 'browse_database', NULL, '2017-04-20 03:43:05', '2017-04-20 03:43:05', NULL),
(3, 'browse_media', NULL, '2017-04-20 03:43:06', '2017-04-20 03:43:06', NULL),
(4, 'browse_settings', NULL, '2017-04-20 03:43:06', '2017-04-20 03:43:06', NULL),
(5, 'browse_menus', 'menus', '2017-04-20 03:43:06', '2017-04-20 03:43:06', NULL),
(6, 'read_menus', 'menus', '2017-04-20 03:43:06', '2017-04-20 03:43:06', NULL),
(7, 'edit_menus', 'menus', '2017-04-20 03:43:06', '2017-04-20 03:43:06', NULL),
(8, 'add_menus', 'menus', '2017-04-20 03:43:07', '2017-04-20 03:43:07', NULL),
(9, 'delete_menus', 'menus', '2017-04-20 03:43:07', '2017-04-20 03:43:07', NULL),
(10, 'browse_roles', 'roles', '2017-04-20 06:43:07', '2017-04-20 06:43:07', NULL),
(11, 'read_roles', 'roles', '2017-04-20 06:43:07', '2017-04-20 06:43:07', NULL),
(12, 'edit_roles', 'roles', '2017-04-20 06:43:07', '2017-04-20 06:43:07', NULL),
(13, 'add_roles', 'roles', '2017-04-20 06:43:07', '2017-04-20 06:43:07', NULL),
(14, 'delete_roles', 'roles', '2017-04-20 06:43:07', '2017-04-20 06:43:07', NULL),
(15, 'browse_users', 'users', '2017-04-20 06:43:08', '2017-04-20 06:43:08', NULL),
(16, 'read_users', 'users', '2017-04-20 06:43:08', '2017-04-20 06:43:08', NULL),
(17, 'edit_users', 'users', '2017-04-20 06:43:08', '2017-04-20 06:43:08', NULL),
(18, 'add_users', 'users', '2017-04-20 06:43:09', '2017-04-20 06:43:09', NULL),
(19, 'delete_users', 'users', '2017-04-20 06:43:09', '2017-04-20 06:43:09', NULL),
(20, 'browse_documents', 'documents', '2017-04-20 06:43:09', '2017-04-20 06:43:09', NULL),
(21, 'read_documents', 'documents', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(22, 'edit_documents', 'documents', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(23, 'add_documents', 'documents', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(24, 'delete_documents', 'documents', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(25, 'browse_articles', 'articles', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(26, 'read_articles', 'articles', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(27, 'edit_articles', 'articles', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(28, 'add_articles', 'articles', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(29, 'delete_articles', 'articles', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(30, 'browse_cities', 'cities', '2017-04-20 06:43:10', '2017-04-20 06:43:10', NULL),
(32, 'edit_cities', 'cities', '2017-04-20 06:43:11', '2017-04-20 06:43:11', NULL),
(33, 'add_cities', 'cities', '2017-04-20 06:43:11', '2017-04-20 06:43:11', NULL),
(35, 'browse_departments', 'departments', '2017-04-20 06:43:12', '2017-04-20 06:43:12', NULL),
(37, 'edit_departments', 'departments', '2017-04-20 06:43:13', '2017-04-20 06:43:13', NULL),
(38, 'add_departments', 'departments', '2017-04-20 06:43:13', '2017-04-20 06:43:13', NULL),
(40, 'browse_positions', 'positions', '2017-04-20 06:43:14', '2017-04-20 06:43:14', NULL),
(42, 'edit_positions', 'positions', '2017-04-20 06:43:14', '2017-04-20 06:43:14', NULL),
(43, 'add_positions', 'positions', '2017-04-20 06:43:15', '2017-04-20 06:43:15', NULL),
(45, 'browse_document_categories', 'document_categories', '2017-04-20 06:43:15', '2017-04-20 06:43:15', NULL),
(46, 'read_document_categories', 'document_categories', '2017-04-20 06:43:16', '2017-04-20 06:43:16', NULL),
(47, 'edit_document_categories', 'document_categories', '2017-04-20 06:43:16', '2017-04-20 06:43:16', NULL),
(48, 'add_document_categories', 'document_categories', '2017-04-20 06:43:16', '2017-04-20 06:43:16', NULL),
(49, 'delete_document_categories', 'document_categories', '2017-04-20 06:43:16', '2017-04-20 06:43:16', NULL),
(50, 'browse_infos', 'infos', '2017-04-20 06:43:16', '2017-04-20 06:43:16', NULL),
(51, 'read_infos', 'infos', '2017-04-20 06:43:17', '2017-04-20 06:43:17', NULL),
(52, 'edit_infos', 'infos', '2017-04-20 06:43:18', '2017-04-20 06:43:18', NULL),
(53, 'add_infos', 'infos', '2017-04-20 06:43:18', '2017-04-20 06:43:18', NULL),
(54, 'delete_infos', 'infos', '2017-04-20 06:43:18', '2017-04-20 06:43:18', NULL),
(55, 'browse_bid_categories', 'bid_categories', '2017-04-20 08:29:48', '2017-04-20 08:29:48', NULL),
(56, 'read_bid_categories', 'bid_categories', '2017-04-20 08:29:48', '2017-04-20 08:29:48', NULL),
(57, 'edit_bid_categories', 'bid_categories', '2017-04-20 08:29:48', '2017-04-20 08:29:48', NULL),
(58, 'add_bid_categories', 'bid_categories', '2017-04-20 08:29:48', '2017-04-20 08:29:48', NULL),
(59, 'delete_bid_categories', 'bid_categories', '2017-04-20 08:29:48', '2017-04-20 08:29:48', NULL),
(65, 'browse_head_of_departments', 'other permissions', NULL, NULL, NULL),
(66, 'browse_hr_managers', 'other permissions', NULL, NULL, NULL),
(67, 'browse_bids', 'other permissions', NULL, NULL, NULL),
(68, 'browse_polls', 'other permissions', NULL, NULL, NULL),
(69, 'browse_dismissed', 'other permissions', NULL, NULL, NULL),
(70, 'read_cities', 'cities', '2017-05-22 08:46:15', '2017-05-22 08:46:15', NULL),
(71, 'delete_cities', 'cities', '2017-05-22 08:46:15', '2017-05-22 08:46:15', NULL),
(72, 'read_departments', 'departments', '2017-05-22 08:46:48', '2017-05-22 08:46:48', NULL),
(73, 'delete_departments', 'departments', '2017-05-22 08:46:48', '2017-05-22 08:46:48', NULL),
(74, 'read_positions', 'positions', '2017-05-22 08:47:01', '2017-05-22 08:47:01', NULL),
(75, 'delete_positions', 'positions', '2017-05-22 08:47:01', '2017-05-22 08:47:01', NULL),
(76, 'browse_backgrounds', 'other permissions', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `permission_groups`
--

CREATE TABLE IF NOT EXISTS `permission_groups` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблиці `permission_role`
--

CREATE TABLE IF NOT EXISTS `permission_role` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 3),
(1, 4),
(1, 6),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(15, 6),
(16, 1),
(16, 6),
(17, 1),
(17, 6),
(18, 1),
(18, 6),
(19, 1),
(19, 6),
(20, 1),
(20, 3),
(21, 1),
(21, 3),
(22, 1),
(22, 3),
(23, 1),
(23, 3),
(24, 1),
(24, 3),
(25, 1),
(25, 6),
(26, 1),
(26, 6),
(27, 1),
(27, 6),
(28, 1),
(28, 6),
(29, 1),
(29, 6),
(30, 1),
(32, 1),
(33, 1),
(35, 1),
(37, 1),
(38, 1),
(40, 1),
(42, 1),
(43, 1),
(45, 1),
(45, 3),
(46, 1),
(46, 3),
(47, 1),
(47, 3),
(48, 1),
(48, 3),
(49, 1),
(49, 3),
(50, 1),
(50, 6),
(51, 1),
(51, 6),
(52, 1),
(52, 6),
(53, 1),
(53, 6),
(54, 1),
(54, 6),
(55, 1),
(56, 1),
(57, 1),
(58, 1),
(59, 1),
(65, 1),
(66, 1),
(67, 1),
(68, 1),
(69, 1),
(76, 1);

-- --------------------------------------------------------

--
-- Структура таблиці `phones`
--

CREATE TABLE IF NOT EXISTS `phones` (
  `user_id` int(10) unsigned NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `phones`
--

INSERT INTO `phones` (`user_id`, `phone`, `created_at`, `updated_at`) VALUES
(390, '+380 95 292 35 40', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(391, '+380 95 292 42 14', '2017-06-13 09:59:02', '2017-06-13 09:59:02'),
(392, '+380 95 292 44 77', '2017-06-13 09:59:02', '2017-06-13 09:59:02'),
(393, '+380 95 292 42 15', '2017-06-13 09:59:02', '2017-06-13 09:59:02'),
(394, '+380 95 292 37 55', '2017-07-03 13:53:02', '2017-07-03 13:53:02'),
(395, '+380 95 292 30 16', '2017-06-13 09:59:02', '2017-06-13 09:59:02'),
(396, '+380 95 292 30 74', '2017-06-13 09:59:02', '2017-06-13 09:59:02'),
(397, '+380 95 292 48 48', '2017-06-13 12:08:34', '2017-06-13 12:08:34'),
(398, '+380 95 292 45 45', '2017-06-13 09:59:02', '2017-06-13 09:59:02'),
(399, '+380 95 292 47 47', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(400, '+380 95 292 30 11', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(401, '+380 95 292 44 22', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(402, '+380 50 367 16 99', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(403, '+380 95 292 30 94', '2017-06-13 12:25:02', '2017-06-13 12:25:02'),
(404, '+380 95 292 30 40', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(405, '+380 95 292 30 10', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(406, '+380 95 292 42 38', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(407, '+380 95 292 37 66', '2017-06-13 09:59:03', '2017-06-13 09:59:03'),
(408, '+380 95 292 30 80', '2017-06-13 09:59:04', '2017-06-13 09:59:04'),
(409, '+380 95 292 30 49', '2017-06-13 09:59:04', '2017-06-13 09:59:04'),
(410, '+380 95 292 30 50', '2017-06-13 09:59:04', '2017-06-13 09:59:04'),
(411, '+380 95 292 30 59', '2017-06-13 09:59:04', '2017-06-13 09:59:04'),
(412, '+380 95 292 30 53', '2017-06-13 09:59:04', '2017-06-13 09:59:04'),
(413, '+380 95 292 30 67', '2017-06-13 09:59:04', '2017-06-13 09:59:04'),
(414, '+380 95 292 37 69', '2017-07-03 13:51:50', '2017-07-03 13:51:50'),
(415, '+380 95 292 30 77', '2017-06-13 09:59:04', '2017-06-13 09:59:04'),
(416, '+380 95 292 42 12', '2017-06-13 09:59:05', '2017-06-13 09:59:05'),
(417, '+380 95 292 42 22', '2017-07-04 08:05:55', '2017-07-04 08:05:55'),
(418, '+380 50 465 79 90', '2017-06-13 09:59:05', '2017-06-13 09:59:05');

-- --------------------------------------------------------

--
-- Структура таблиці `polls`
--

CREATE TABLE IF NOT EXISTS `polls` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `end` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `polls`
--

INSERT INTO `polls` (`id`, `name`, `start`, `end`, `created_at`, `updated_at`) VALUES
(14, 'Вы?', '2017-07-03 13:18:25', '2017-08-20 12:57:00', '2017-07-03 12:59:45', '2017-07-03 13:18:25');

-- --------------------------------------------------------

--
-- Структура таблиці `positions`
--

CREATE TABLE IF NOT EXISTS `positions` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `positions`
--

INSERT INTO `positions` (`id`, `name`, `created_at`, `updated_at`) VALUES
(45, 'Начальник коммерческого отдела', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(46, 'Менеджер по сбыту', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(47, 'Менеджер по закупкам', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(48, 'Менеджер по логистике департамента продаж', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(49, 'Младший специалист', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(50, 'Младший специалист отдела бухгалтерского и налогового учета', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(51, 'Главный бухгалтер', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(52, 'Администратор системы', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(53, 'Делопроизводитель', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(54, 'Директор департамента продаж', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(55, 'Менеджер проектов', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(56, 'Менеджер по связям с общественностью', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(57, 'Начальник отдела системного администрирования', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(58, 'Директор по персоналу', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(59, 'Финансовый директор', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(60, 'Ведущий аудитор', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(61, 'Начальник отдела бухгалтерского и налогового учета', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(62, 'Начальник отдела казначейских операций', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(63, 'Начальник отдела финансовой отчетности', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(64, 'Директор по правовому обеспечению', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(65, 'Юрисконсульт', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(66, 'Начальник отдела юридической практики', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(67, 'Ведущий специалист отдела корпоративных финансов', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(68, 'Экономист отдела бюджетирования', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(69, 'Помощник Генерального директора', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(70, 'Начальник отдела договорной работы и согласований', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(71, 'Делопроизводитель департамента по связям с общественностью', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(72, 'Генеральный директор', '2017-06-13 09:51:27', '2017-06-13 09:51:27'),
(73, 'Ведущий экономист по бюджетированию', '2017-07-03 13:51:13', '2017-07-03 13:51:13');

-- --------------------------------------------------------

--
-- Структура таблиці `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bid_responsible` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `bid_responsible`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администратор', 0, NULL, '2017-04-25 08:14:01'),
(2, 'user', 'Пользователь', 0, NULL, '2017-04-25 08:14:37'),
(3, 'file manager', 'Менеджер Файлов', 0, '2017-04-25 08:15:40', '2017-04-25 08:15:40'),
(4, 'hr', 'HR - менеджер', 1, '2017-04-25 08:17:25', '2017-05-03 12:15:54'),
(6, 'head of department', 'Глава департамента', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `role_departments_emails`
--

CREATE TABLE IF NOT EXISTS `role_departments_emails` (
  `id` int(10) unsigned NOT NULL,
  `role_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп даних таблиці `role_departments_emails`
--

INSERT INTO `role_departments_emails` (`id`, `role_id`, `department_id`, `city_id`, `email`, `created_at`, `updated_at`) VALUES
(10, 6, 16, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(11, 6, 17, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(12, 6, 18, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(13, 6, 19, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(14, 6, 20, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(15, 6, 21, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(16, 6, 22, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(17, 6, 23, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03'),
(18, 6, 24, 3, 'development4@leostudio.com.ua', '2017-06-16 08:59:03', '2017-06-16 08:59:03');

-- --------------------------------------------------------

--
-- Структура таблиці `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) unsigned NOT NULL,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблиці `tags`
--

CREATE TABLE IF NOT EXISTS `tags` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `tags`
--

INSERT INTO `tags` (`id`, `name`, `created_at`, `updated_at`) VALUES
(48, 'harveast', '2017-06-16 08:06:37', '2017-06-16 08:06:37'),
(49, 'тесттег', '2017-06-16 08:37:01', '2017-06-16 08:37:01'),
(50, 'test', '2017-06-16 08:41:03', '2017-06-16 08:41:03');

-- --------------------------------------------------------

--
-- Структура таблиці `translations`
--

CREATE TABLE IF NOT EXISTS `translations` (
  `id` int(10) unsigned NOT NULL,
  `table_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foreign_key` int(10) unsigned NOT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблиці `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthday` datetime DEFAULT '0000-00-00 00:00:00',
  `city_id` int(10) unsigned NOT NULL DEFAULT '0',
  `department_id` int(10) unsigned NOT NULL DEFAULT '0',
  `position_id` int(10) unsigned NOT NULL DEFAULT '0',
  `boss_id` int(10) unsigned NOT NULL DEFAULT '0',
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '/storage/app/public/users/simple.png',
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=420 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `birthday`, `city_id`, `department_id`, `position_id`, `boss_id`, `photo`, `email`, `password`, `is_active`, `remember_token`, `created_at`, `updated_at`, `avatar`) VALUES
(1, 1, 'Nikko Ruecker', '2017-05-22 00:00:00', 3, 16, 45, 0, '/storage/app/public/users/littel.edna@example.net/oS9tke2HxL51HB5gPXKCSxnQ4sIjKIv4OGz3tNTd.jpeg', 'development4@leostudio.com.ua', '$2y$10$lrVDyieeio2B1QlGB.0lCO1Wl9NUiH3NURpTDX2XFY.g3dCUhCRcy', 1, 'XOHt6QwuqiJd7DlCcPUTGrqojmvL7FDXXxdfMoUEywPiaNzOGuMapsLyihoT', '2017-04-20 06:41:54', '2017-05-23 15:13:42', NULL),
(390, 2, 'Шелест Елена', '1975-08-31 00:00:00', 3, 25, 45, 0, '/storage/app/public/users/Elena.Shelest/nRFeVM0WAs.jpg', 'Elena.Shelest@harveast.com', '$2y$10$n/d5bfgxU/tW45FEMTbb6u9Jd6wdCqoisuea0fmxFcOtfjrTXAF26', 1, NULL, NULL, '2017-06-13 09:51:27', 'users/default.png'),
(391, 2, 'Гнаповский Владимир', '1993-07-21 00:00:00', 3, 25, 46, 0, '/storage/app/public/users/Vladimir.Gnapovskiy/73Xk0kGK0r.jpg', 'Vladimir.Gnapovskiy@harveast.com', '$2y$10$wLvbweCqyz70F50wmT.puecEYNIkvzswIvFkPylN0.0EJr/E4sG3W', 1, NULL, NULL, '2017-06-13 09:59:02', 'users/default.png'),
(392, 2, 'Дудак Дмитрий', '1980-05-22 00:00:00', 3, 25, 47, 0, '/storage/app/public/users/Dmitriy.Dudak/FamU5GBA0K.jpg', 'Dmitriy.Dudak@harveast.com', '$2y$10$.lBRqXJ46QtCCA00R3fXyuCEXW66WI4LP5YAqX8iZAaNalnpQIhN.', 1, NULL, NULL, '2017-06-13 09:59:02', 'users/default.png'),
(393, 2, 'Мисчанчук Светлана', '1963-03-19 00:00:00', 3, 25, 48, 0, '/storage/app/public/users/Svetlana.Mischanchuk/gyaOFgPtGo.jpg', 'Svetlana.Mischanchuk@harveast.com', '$2y$10$GynAS2SAMrKYOkVhC9Z/uOufSY9XjvJWOQXJ7psUo148VpYCwFlQm', 1, NULL, NULL, '2017-06-13 09:59:02', 'users/default.png'),
(394, 2, 'Плетнева Юлия', '1993-07-02 00:00:00', 3, 17, 68, 0, '/storage/app/public/users/Yuliya.Pletneva/g1k9NyPui0.jpg', 'Yuliya.Pletneva@harveast.com', '$2y$10$PjsrUD1tESKxGGBxhAEbJedY44m2Pa5tkCnLCEpKclIBYd20SbXwa', 1, NULL, NULL, '2017-06-13 09:59:02', 'users/default.png'),
(395, 2, 'Кайдаш Виталий', '1992-12-19 00:00:00', 3, 25, 50, 0, '/storage/app/public/users/Vitaliy.Kaydash/NFowTqGlHX.jpg', 'Vitaliy.Kaydash@harveast.com', '$2y$10$bkNnhtUU3mP2dliobNFjveGRr5pd3FlkVOtu5grMLupunW8li1APW', 1, NULL, NULL, '2017-06-13 09:59:02', 'users/default.png'),
(396, 2, 'Маркуш Елена', '1987-05-12 00:00:00', 3, 17, 51, 0, '/storage/app/public/users/Elena.Markush/XNk9oaYEYP.jpg', 'Elena.Markush@harveast.com', '$2y$10$xRDtkgYE1ocT6ZaG/4MiJ.uQkipSo1AmOnSA5OklAXHBUtHSpFSxi', 1, 'YvZiq5wk803etbzicB57MTBBSuQL1BwlBFjOjarOHeGHFbUq6BC2c9WYBYa7', NULL, '2017-06-13 09:59:02', 'users/default.png'),
(397, 1, 'Пашко Андрей', '1994-08-13 00:00:00', 3, 18, 52, 403, '/storage/app/public/users/Andrey.Pashko/A557puuQa9.jpg', 'Andrey.Pashko@harveast.com', '$2y$10$16syl49Pu6BDUzIpvZESX.PiK7jbiWZ0suwfyUsUGfYrxCuQybB9a', 1, 'RUDHSjBm1bhTXWZ2dAT502q2TFh9BS8xGuzc5pMUHdTftZh8NiQbLY4YH9g8', NULL, '2017-06-13 09:59:02', 'users/default.png'),
(398, 2, 'Рыжкина Наталья', '1985-08-17 00:00:00', 3, 19, 53, 0, '/storage/app/public/users/Natalya.Ryzhkina/r6YtjF2kq9.jpg', 'Natalya.Ryzhkina@harveast.com', '$2y$10$6f5nznapOP9YFkQQjmMHzeL3f5ux2B61XXR3U.D2kRGP.83r4gz6S', 1, NULL, NULL, '2017-06-13 09:59:02', 'users/default.png'),
(399, 2, 'Алавердова Татьяна', '1977-08-23 00:00:00', 3, 20, 54, 0, '/storage/app/public/users/Tatyana.Alaverdova/nyEMZpZIdh.jpg', 'Tatyana.Alaverdova@harveast.com', '$2y$10$y/fPOQqQx9H9RBoMkrGKj.7tWB8aQiFDlPCnE8isd439j411eV.FK', 1, NULL, NULL, '2017-06-13 09:59:03', 'users/default.png'),
(400, 2, 'Драгун Виктория', '1985-05-20 00:00:00', 3, 17, 51, 0, '/storage/app/public/users/Viktorya.Dragun/jGV6MBFtZt.jpg', 'Viktorya.Dragun@harveast.com', '$2y$10$GGMG0.4av9rYWsXVjw/moO.YqD7NZJTB0RypNn.Nq1f7Ffq79wlVW', 1, 'hbxRG0904h1jDzVBeHGtVXTBkrcwfjr5TZRP22sr5mWNj3qpW9VtjrMYLmuH', NULL, '2017-06-13 09:59:03', 'users/default.png'),
(401, 2, 'Закусилов Петр', '1978-06-06 00:00:00', 3, 25, 55, 0, '/storage/app/public/users/Petr.Zakusilov/HPW5uD1GKy.jpg', 'Petr.Zakusilov@harveast.com', '$2y$10$joMenhYoida4n3hehcdj8O7F3mkU2xEFl9jvQuhoDA8VzwqSIJpuy', 1, NULL, NULL, '2017-06-13 09:59:03', 'users/default.png'),
(402, 2, 'Зубарева Елена', '1983-09-18 00:00:00', 3, 21, 56, 0, '/storage/app/public/users/Elena.Zubareva/DWxNJHJiPX.jpg', 'Elena.Zubareva@harveast.com', '$2y$10$Ss4mA4c43uFR0XWyRLgPdeIRZ1ei0X6UCq8pdKhAjNE8ticR7YfpC', 0, NULL, NULL, '2017-06-13 09:59:03', 'users/default.png'),
(403, 1, 'Казьмин Артем', '1983-10-18 00:00:00', 3, 18, 57, 405, '/storage/app/public/users/Artem.Kazmin/VJI5tULKfk.jpg', 'Artem.Kazmin@harveast.com', '$2y$10$qaXoNZwvyf/Weji/HjNqu.4zM3C39AZ9c5cUCR4iUtdMs3JbL33FO', 1, '3zQtJM8X63bfRuCSkKtD5xShMjYbSTmfVZF0ZFrvR9DnvAHH58pg0a8om0vb', NULL, '2017-06-13 09:59:03', 'users/default.png'),
(404, 2, 'Клочан Лидия', '1977-08-11 00:00:00', 3, 22, 58, 0, '/storage/app/public/users/Lidia.Klochan/VXsh5mMdaE.jpg', 'Lidia.Klochan@harveast.com', '$2y$10$qDhDrzQhR3weTfSLZNrup.ka3vJfrSbAykZu7zgcJ/kMVy8IY0s0e', 1, NULL, NULL, '2017-06-13 09:59:03', 'users/default.png'),
(405, 2, 'Колыбашкин Виктор', '1988-07-24 00:00:00', 3, 17, 59, 0, '/storage/app/public/users/Viktor.Kolybashkin/aQl4aIDub6.jpg', 'Viktor.Kolybashkin@harveast.com', '$2y$10$5WEjZ/PHOh1nqhNVfeQ3V.IXhk/pPMFrAPR6aDGE8tjlsuK.rJhxi', 1, '7dY2fk0f8GPX0RLSjhN9GghdYLv83VRSfR6U942xzTk9DNQYrUCp63g0gqOK', NULL, '2017-06-13 09:59:03', 'users/default.png'),
(406, 2, 'Лыман Олег', '1980-10-25 00:00:00', 3, 23, 60, 0, '/storage/app/public/users/Oleg.Lyman/apRA5n2DQO.jpg', 'Oleg.Lyman@harveast.com', '$2y$10$nc6wulRxYobpxW2wCHkhlexhmjLbDAX2mzyY6ge3z8EKgARnnGc3S', 1, NULL, NULL, '2017-06-13 09:59:03', 'users/default.png'),
(407, 2, 'Остапенко Алексей', '1988-05-27 00:00:00', 3, 17, 61, 0, '/storage/app/public/users/Aleksey.Ostapenko/YauqEO6J7f.jpg', 'Aleksey.Ostapenko@harveast.com', '$2y$10$GmCcpoUd/bocz3qG7HK9MuKn6FXiTuVJy7PlJc2zGJK.02y.K5jU2', 1, NULL, NULL, '2017-06-13 09:59:03', 'users/default.png'),
(408, 2, 'Папина Инна', '1988-11-08 00:00:00', 3, 17, 62, 0, '/storage/app/public/users/Inna.Papina/aMA3OsuNAU.jpg', 'Inna.Papina@harveast.com', '$2y$10$Z7Q9h0DkayBo3jkZTK1b1e4E4oeDRTQAAIkPqV0BGr6WSFTOiswBa', 1, 'OGnXqobjsuSWVDRFRPV5BvUxzasgaNr70VB2DFUzvoZALAcSISWbFb9IhTEe', NULL, '2017-06-13 09:59:04', 'users/default.png'),
(409, 2, 'Пономарев Виктор', '1988-12-05 00:00:00', 3, 17, 63, 0, '/storage/app/public/users/Viktor.Ponomaryov/tpx28PbEcQ.jpg', 'Viktor.Ponomaryov@harveast.com', '$2y$10$z7QdleOEH9wgCErUehc8wu6WbBC4vCJ37y6FL00GqxwwQ0RZirBxa', 1, NULL, NULL, '2017-06-13 09:59:04', 'users/default.png'),
(410, 2, 'Селихов Максим', '1977-09-01 00:00:00', 3, 24, 64, 0, '/storage/app/public/users/Maksim.Selikhov/fKXMm7n93L.jpg', 'Maksim.Selikhov@harveast.com', '$2y$10$0sCyrMcSVgS9Pxe2CB3Q5ugWnQDJ38hN5o5qBDGbkAwudjkxchrmO', 1, NULL, NULL, '2017-06-13 09:59:04', 'users/default.png'),
(411, 2, 'Семений Елена', '1989-02-11 00:00:00', 3, 24, 65, 0, '/storage/app/public/users/elena.semeniy/38JKncp27a.jpg', 'elena.semeniy@harveast.com', '$2y$10$KovxUgT9S5Gk1DZqRKlADuW32P4spteVPVa5gjVyFyfrLxF37R82K', 1, NULL, NULL, '2017-06-13 09:59:04', 'users/default.png'),
(412, 2, 'Сиринёк Оксана', '1978-05-20 00:00:00', 3, 24, 66, 0, '/storage/app/public/users/Oksana.Sirinek/Li6gcaCsLo.jpg', 'Oksana.Sirinek@harveast.com', '$2y$10$XAfhQaOnSBUoGvH7GZVQK.e8k4rUmZ1PaBGfXPJFmuIP1NFvD/QIG', 1, NULL, NULL, '2017-06-13 09:59:04', 'users/default.png'),
(413, 2, 'Смирнова Марина', '1988-05-29 00:00:00', 3, 17, 67, 0, '/storage/app/public/users/Marina.Smirnova/iFEmFNcplm.jpg', 'Marina.Smirnova@harveast.com', '$2y$10$E2cMoHULXyMLNuwJMjl4GeF9H.B/URsxttVhKCqYKOsKcNE6.fMqq', 1, NULL, NULL, '2017-06-13 09:59:04', 'users/default.png'),
(414, 2, 'Сосункевич Оксана', '1991-01-14 00:00:00', 3, 17, 73, 0, '/storage/app/public/users/Oksana.Sosunkevich/FpSysMKK1v.jpg', 'Oksana.Sosunkevich@harveast.com', '$2y$10$hqS8rfOslwfw9SHEXw2s.uENGIMO7y2l6Ia7lnR3xJOjg7yycNyyu', 1, NULL, NULL, '2017-06-13 09:59:04', 'users/default.png'),
(415, 2, 'Швец Вероника', '1987-11-07 00:00:00', 3, 19, 69, 0, '/storage/app/public/users/assistant.od/fF44MFAyCC.jpg', 'assistant.od@harveast.com', '$2y$10$I4sYkelwJ2MiDlRhbU7sAuQ8CtcXkw47oxQ4bXC/6ii7p3ESKcUKi', 1, NULL, NULL, '2017-06-13 09:59:04', 'users/default.png'),
(416, 2, 'Юкселен Яна', '1985-02-09 00:00:00', 3, 24, 70, 0, '/storage/app/public/users/Yana.Yukselen/LIOJI8THvW.jpg', 'Yana.Yukselen@harveast.com', '$2y$10$uaJyk5wr0IB88tV2CP/48.M4VOsCCarIHbjM738w..pvQebAJFF2G', 1, NULL, NULL, '2017-06-13 09:59:05', 'users/default.png'),
(417, 1, 'Ковальчук Наталья', '1984-05-25 00:00:00', 3, 17, 53, 1, '/storage/app/public/users/Natalya.Kovalchuk/t4dJIrFJPg.jpg', 'Natalya.Kovalchuk@harveast.com', '$2y$10$0Vs0L889wzU5J8LKXCfI1uaKRt7/dn9imjghfPMOEBuSswadZy8c6', 1, '3Hu1abDLgAE2YsWLCDw9oE2a3nR2NYBK5LMMtmuLOeub1bhEsaSzUzvo3MVw', NULL, '2017-06-13 09:59:05', 'users/default.png'),
(418, 2, 'Скорняков Дмитрий', '1978-09-19 00:00:00', 3, 25, 72, 0, '/storage/app/public/users/Dmitry.Skornyakov/ihLUSNfHmy.jpg', 'Dmitry.Skornyakov@harveast.com', '$2y$10$ANQpKVsbNP.n4VaBjsr9BeYXbwQjvIzF7KEBLe7ngk4UK0TuBtdWm', 1, NULL, NULL, '2017-06-13 09:59:05', 'users/default.png'),
(419, 2, 'тест', NULL, 3, 16, 45, 1, '/storage/app/public/users/it@harveast.com/iLkY07KZLUceNONj793ee93K7HVp5RYSzxA23mu3.png', 'it@harveast.com', '$2y$10$LnCRnWGV9SPFuZmwwmou5uMkEcLCtcepMZhH3JeMVfPzJ5pXINZ3C', 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `user_bids`
--

CREATE TABLE IF NOT EXISTS `user_bids` (
  `id` int(10) unsigned NOT NULL,
  `bid_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Дамп даних таблиці `user_bids`
--

INSERT INTO `user_bids` (`id`, `bid_id`, `user_id`, `data`, `status`, `created_at`, `updated_at`) VALUES
(158, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:02:30', '2017-06-16 09:02:30'),
(159, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:03:01', '2017-06-16 09:03:01'),
(160, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:06:37', '2017-06-16 09:06:37'),
(161, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:08:19', '2017-06-16 09:08:19'),
(162, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:10:40', '2017-06-16 09:10:40'),
(163, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:11:56', '2017-06-16 09:11:56'),
(164, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:20:47', '2017-06-16 09:20:47'),
(165, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:22:07', '2017-06-16 09:22:07'),
(166, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:40:13', '2017-06-16 09:40:13'),
(167, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:41:24', '2017-06-16 09:41:24'),
(168, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:41:36', '2017-06-16 09:41:36'),
(169, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:42:19', '2017-06-16 09:42:19'),
(170, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:54:25', '2017-06-16 09:54:25'),
(171, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 09:55:07', '2017-06-16 09:55:07'),
(172, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:02:20', '2017-06-16 10:02:20'),
(173, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:02:52', '2017-06-16 10:02:52'),
(174, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:07:00', '2017-06-16 10:07:00'),
(175, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:07:04', '2017-06-16 10:07:04'),
(176, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:07:35', '2017-06-16 10:07:35'),
(177, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:08:13', '2017-06-16 10:08:13'),
(178, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:08:29', '2017-06-16 10:08:29'),
(179, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:10:05', '2017-06-16 10:10:05'),
(180, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:12:39', '2017-06-16 10:12:39'),
(181, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:15:43', '2017-06-16 10:15:43'),
(182, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:16:15', '2017-06-16 10:16:15'),
(183, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:18:39', '2017-06-16 10:18:39'),
(184, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:18:53', '2017-06-16 10:18:53'),
(185, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:19:27', '2017-06-16 10:19:27'),
(186, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";a:3:{s:5:"field";s:6:"upload";s:5:"label";s:9:"тест3";s:8:"required";i:0;}}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";a:5:{s:5:"field";s:5:"files";s:5:"label";s:9:"тест4";s:5:"files";a:2:{i:0;a:1:{s:3:"src";s:71:"storage/app/public/bids/testovyiy-vopros/iel.swaniawski@example.net.jpg";}i:1;a:1:{s:3:"src";s:63:"storage/app/public/bids/testovyiy-vopros/qwerty@example.com.jpg";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:21:41', '2017-06-16 10:21:41'),
(187, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:24:45', '2017-06-16 10:24:45'),
(188, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:25:12', '2017-06-16 10:25:12'),
(189, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:25:33', '2017-06-16 10:25:33'),
(190, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:27:00', '2017-06-16 10:27:00'),
(191, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:27:09', '2017-06-16 10:27:09'),
(192, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:27:22', '2017-06-16 10:27:22'),
(193, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:27:36', '2017-06-16 10:27:36'),
(194, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:29:29', '2017-06-16 10:29:29'),
(195, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";a:3:{s:5:"field";s:4:"text";s:5:"label";s:9:"тест1";s:8:"required";i:0;}}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";a:6:{s:5:"field";s:6:"number";s:5:"label";s:9:"тест2";s:3:"min";i:1;s:3:"max";i:33;s:4:"step";i:1;s:8:"required";i:0;}}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";a:5:{s:5:"field";s:5:"texts";s:5:"label";s:9:"тест5";s:5:"texts";a:2:{i:0;a:1:{s:4:"text";s:11:"текст1";}i:1;a:1:{s:4:"text";s:11:"текст2";}}s:8:"box_type";s:5:"radio";s:8:"required";i:0;}}}', 'pending', '2017-06-16 10:33:25', '2017-06-16 10:33:25'),
(196, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:8:"тест";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:1:"1";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:11:"текст1";}}', 'pending', '2017-06-16 10:40:19', '2017-06-16 10:40:19'),
(197, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:8:"тест";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:1:"1";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:11:"текст1";}}', 'pending', '2017-06-16 10:40:36', '2017-06-16 10:40:36'),
(198, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:8:"тест";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:1:"1";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:11:"текст1";}}', 'pending', '2017-06-16 10:40:50', '2017-06-16 10:40:50'),
(199, 38, 1, 'a:3:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:8:"тест";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:1:"1";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:11:"текст1";}}', 'pending', '2017-06-16 10:41:20', '2017-06-16 10:41:20'),
(200, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:6:"attach";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:6:"attach";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:6:"attach";}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";s:6:"attach";}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";s:6:"attach";}}', 'pending', '2017-06-16 10:57:30', '2017-06-16 10:57:30'),
(201, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:6:"attach";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:6:"attach";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:6:"attach";}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";s:6:"attach";}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";s:6:"attach";}}', 'pending', '2017-06-16 10:58:17', '2017-06-16 10:58:17'),
(202, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:6:"attach";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:6:"attach";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:6:"attach";}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";s:6:"attach";}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";s:6:"attach";}}', 'pending', '2017-06-16 10:58:52', '2017-06-16 10:58:52'),
(203, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:6:"attach";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:6:"attach";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:6:"attach";}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";s:6:"attach";}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";s:6:"attach";}}', 'pending', '2017-06-16 10:59:06', '2017-06-16 10:59:06'),
(204, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:6:"attach";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:6:"attach";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:6:"attach";}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";s:6:"attach";}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";s:6:"attach";}}', 'pending', '2017-06-16 11:00:34', '2017-06-16 11:00:34'),
(205, 38, 1, 'a:5:{i:0;a:2:{s:5:"label";s:9:"тест1";s:5:"value";s:8:"ыфыв";}i:1;a:2:{s:5:"label";s:9:"тест2";s:5:"value";s:1:"1";}i:2;a:2:{s:5:"label";s:9:"тест5";s:5:"value";s:11:"текст1";}i:3;a:2:{s:5:"label";s:9:"тест3";s:5:"value";s:6:"attach";}i:4;a:2:{s:5:"label";s:9:"тест4";s:5:"value";s:6:"attach";}}', 'pending', '2017-06-16 11:02:40', '2017-06-16 11:02:40');

-- --------------------------------------------------------

--
-- Структура таблиці `views`
--

CREATE TABLE IF NOT EXISTS `views` (
  `id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Структура таблиці `votes`
--

CREATE TABLE IF NOT EXISTS `votes` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `articles_slug_unique` (`slug`);

--
-- Індекси таблиці `article_tags`
--
ALTER TABLE `article_tags`
  ADD PRIMARY KEY (`article_id`,`tag_id`),
  ADD KEY `article_tags_article_id_index` (`article_id`),
  ADD KEY `article_tags_tag_id_index` (`tag_id`);

--
-- Індекси таблиці `article_views`
--
ALTER TABLE `article_views`
  ADD PRIMARY KEY (`article_id`,`user_id`),
  ADD KEY `article_views_article_id_index` (`article_id`),
  ADD KEY `article_views_user_id_index` (`user_id`);

--
-- Індекси таблиці `bids`
--
ALTER TABLE `bids`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `bid_categories`
--
ALTER TABLE `bid_categories`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_slug_unique` (`slug`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Індекси таблиці `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cities_name_unique` (`name`);

--
-- Індекси таблиці `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `data_rows`
--
ALTER TABLE `data_rows`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_rows_data_type_id_foreign` (`data_type_id`);

--
-- Індекси таблиці `data_types`
--
ALTER TABLE `data_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_types_name_unique` (`name`),
  ADD UNIQUE KEY `data_types_slug_unique` (`slug`);

--
-- Індекси таблиці `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `departments_name_unique` (`name`);

--
-- Індекси таблиці `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `document_categories`
--
ALTER TABLE `document_categories`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `infos`
--
ALTER TABLE `infos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `infos_city_id_index` (`city_id`),
  ADD KEY `infos_department_id_index` (`department_id`);

--
-- Індекси таблиці `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_name_unique` (`name`);

--
-- Індекси таблиці `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menu_items_menu_id_foreign` (`menu_id`);

--
-- Індекси таблиці `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Індекси таблиці `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissions_key_index` (`key`);

--
-- Індекси таблиці `permission_groups`
--
ALTER TABLE `permission_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permission_groups_name_unique` (`name`);

--
-- Індекси таблиці `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_permission_id_index` (`permission_id`),
  ADD KEY `permission_role_role_id_index` (`role_id`);

--
-- Індекси таблиці `phones`
--
ALTER TABLE `phones`
  ADD PRIMARY KEY (`user_id`,`phone`),
  ADD KEY `phones_user_id_index` (`user_id`);

--
-- Індекси таблиці `polls`
--
ALTER TABLE `polls`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `positions`
--
ALTER TABLE `positions`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Індекси таблиці `role_departments_emails`
--
ALTER TABLE `role_departments_emails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_departments_emails_role_id_index` (`role_id`),
  ADD KEY `role_departments_emails_department_id_index` (`department_id`),
  ADD KEY `role_departments_emails_city_id_index` (`city_id`);

--
-- Індекси таблиці `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

--
-- Індекси таблиці `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tags_name_unique` (`name`);

--
-- Індекси таблиці `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `translations_table_name_column_name_foreign_key_locale_unique` (`table_name`,`column_name`,`foreign_key`,`locale`);

--
-- Індекси таблиці `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Індекси таблиці `user_bids`
--
ALTER TABLE `user_bids`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `views`
--
ALTER TABLE `views`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT для таблиці `bids`
--
ALTER TABLE `bids`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT для таблиці `bid_categories`
--
ALTER TABLE `bid_categories`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблиці `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблиці `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблиці `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблиці `data_rows`
--
ALTER TABLE `data_rows`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT для таблиці `data_types`
--
ALTER TABLE `data_types`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT для таблиці `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT для таблиці `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблиці `document_categories`
--
ALTER TABLE `document_categories`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблиці `infos`
--
ALTER TABLE `infos`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT для таблиці `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблиці `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT для таблиці `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT для таблиці `options`
--
ALTER TABLE `options`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=79;
--
-- AUTO_INCREMENT для таблиці `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT для таблиці `permission_groups`
--
ALTER TABLE `permission_groups`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблиці `polls`
--
ALTER TABLE `polls`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT для таблиці `positions`
--
ALTER TABLE `positions`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=74;
--
-- AUTO_INCREMENT для таблиці `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблиці `role_departments_emails`
--
ALTER TABLE `role_departments_emails`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT для таблиці `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблиці `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT для таблиці `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблиці `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=420;
--
-- AUTO_INCREMENT для таблиці `user_bids`
--
ALTER TABLE `user_bids`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=206;
--
-- AUTO_INCREMENT для таблиці `views`
--
ALTER TABLE `views`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблиці `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- Обмеження зовнішнього ключа збережених таблиць
--

--
-- Обмеження зовнішнього ключа таблиці `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Обмеження зовнішнього ключа таблиці `data_rows`
--
ALTER TABLE `data_rows`
  ADD CONSTRAINT `data_rows_data_type_id_foreign` FOREIGN KEY (`data_type_id`) REFERENCES `data_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Обмеження зовнішнього ключа таблиці `menu_items`
--
ALTER TABLE `menu_items`
  ADD CONSTRAINT `menu_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE;

--
-- Обмеження зовнішнього ключа таблиці `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
